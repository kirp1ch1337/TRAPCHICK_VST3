﻿$ErrorActionPreference = "Stop"

if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
throw "CMake not found. Install CMake and restart PowerShell."
}

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
throw "Git not found. Install Git and restart PowerShell."
}

$ProjectDir = $PSScriptRoot
$BuildDir = Join-Path $ProjectDir "build"
$JuceDir = Join-Path $ProjectDir "JUCE"

if (-not (Test-Path $JuceDir)) {
 git clone --branch 8.0.6 --depth 1 https://github.com/juce-framework/JUCE.git $JuceDir
if ($LASTEXITCODE -ne 0) {
throw "Failed to download JUCE."
}
}

cmake -S $ProjectDir -B $BuildDir -G "Visual Studio 17 2022" -A x64 "-DJUCE_DIR=$JuceDir"
if ($LASTEXITCODE -ne 0) {
throw "CMake configuration failed."
}

cmake --build $BuildDir --config Release --target TRAPCHIK_VST3
if ($LASTEXITCODE -ne 0) {
throw "VST3 build failed."
}

Write-Host "Build finished. Check the build folder for TRAPCHIK.vst3."
